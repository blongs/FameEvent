package v2

import "github.com/davyxu/golog"

var log *golog.Logger = golog.New("exportorv2")
