package filter

import (
	"github.com/davyxu/golog"
)

var log *golog.Logger = golog.New("filter")
